
const getters = {
    notes:state => state.notes,
    activeNote:state =>state.activeNote
}


export default getters;