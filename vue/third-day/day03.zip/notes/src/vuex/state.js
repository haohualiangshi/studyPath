
const state = {
    notes:[],
    activeNote:[]
}


export default state;