
export const ADD_NOTE = 'ADD_NOTE'
export const EDIT_TEXT = 'EDIT_TEXT'
export const SET_ACTIVE_NOTE = 'SET_ACTIVE_NOTE'
export const TOGGLE_FAVORITE = 'TOGGLE_FAVORITE'
export const DELETE_NOTE = 'DELETE_NOTE'