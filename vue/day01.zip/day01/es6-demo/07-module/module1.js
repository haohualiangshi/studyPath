

export default function add(x,y){
	return  x+y;
}

var abc = 101;

export {abc};
