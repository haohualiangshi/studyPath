import add,{abc} from './module1'

console.log(add(1,2));

console.log(abc);